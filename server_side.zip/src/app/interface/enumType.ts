export type yesNoType = 'হ্যাঁ' | 'না' 


